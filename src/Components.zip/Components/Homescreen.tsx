import React from 'react'
import { NavLink } from 'react-router-dom'
import Hero from './Hero'
import Solutions from './Solutions'

const Homescreen = () => {
  return (
    <div>
        <Hero />
        <Solutions />
    </div>
  )
}

export default Homescreen