import React from 'react'
import styled from 'styled-components'

const Solutions = () => {
  return (
    <Container>
        <Top>Atlassian solutions are designed for all types of work</Top>
        <Hold>
            <Button><Text>Work management</Text></Button>
            <Button2><Text>IT Service Management</Text></Button2>
            <Button2><Text>Agile and DevOps</Text></Button2>
        </Hold>
    </Container>
  )
}

export default Solutions
const Text = styled.h2`
    
`
const Button = styled.div`
    width: 350px;
    height: 95px;
    background-color: #0065FF;
    margin-right: 25px;
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50px;
    color: white;
`
const Button2 = styled.div`
    width: 350px;
    height: 95px;
    background-color: #DEEBFF;
    margin-right: 25px;
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50px;
    color: #0065FF;
`

const Hold = styled.div`
    width: 80%;
    display: flex;
    margin-top: 20px;
`

const Top = styled.h2`
    color: #253858;
    font-size: 30px;
`

const Container = styled.div`
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
`